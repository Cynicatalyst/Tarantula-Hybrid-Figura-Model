models:setSecondaryRenderType("Eyes")
if client.compareVersions(client:getVersion(), "1.21.4") < 0 then
  function events.tick()
    models:setSecondaryColor(math.map(
      world.getLightLevel(player:getPos()),
      0, 15,
      1, 0)
    )
  end
else
  local emissives
  local function load()
    emissives = {}
    for _, texture in ipairs(models:getTextures()) do
      if texture:getName():match("_e$") then
        emissives[#emissives + 1] = { texture, texture:getDimensions():unpack() }
      end
    end
  end
  function events.resource_reload()
    load()
  end
  load()
  local light = -1
  local _light = -1
  function events.tick()
    _light = light
    light = world.getLightLevel(player:getPos())
    if light == _light then return end
    local matr = matrices.mat4() * math.map(
      light,
      0, 15,
      1, 0.3)
    for _, data in ipairs(emissives) do
      data[1]:restore()
      data[1]:applyMatrix(0, 0, data[2], data[3], matr)
      data[1]:update()
    end
  end
end