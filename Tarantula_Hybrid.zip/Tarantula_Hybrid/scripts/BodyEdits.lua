-- Hides the vanilla player skin layers
vanilla_model.OUTER_LAYER:setVisible(false)
vanilla_model.INNER_LAYER:setVisible(false)

-- To keep parots, elytra, and armour visible 
vanilla_model.ARMOR:setVisible(true)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(true)
vanilla_model.BOOTS:setVisible(false)
vanilla_model.LEGGINGS:setVisible(false)